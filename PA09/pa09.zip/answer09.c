#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include "answer09.h"

char * * explode(const char * str, const char * delims, int * arrLen);
/*
 * Construct one BusinessNode. You need to allocate memory for this node first.
 *
 * The caller needs to make sure to use strdup(...) for the arguments, do not
 * use strdup(...) inside of this function.
 *
 * stars: the stars of this business
 * name: name of this business
 * address: address of this business
 */
BusinessNode * create_node(char * stars, char * name, char * address)
{
  BusinessNode * node = malloc(sizeof(BusinessNode));
  node ->name = name;
  node ->stars = stars; 
  node ->address = address;  
  node->left = NULL; 
  node->right = NULL;
  return node;
}


/* Insert a node into a BST. Primarily used in load_tree_from_file(). Return a
 * pointer to the root of the BST.
 */
BusinessNode * tree_insert(BusinessNode * node, BusinessNode * root)
{
  if(root == NULL) 
    { 
      return node;
    }
  if(strcmp((node->name),root->name) <= 0) 
    { 
      root->left = tree_insert (node,root->left);
    } 
  else 
    {
      root->right = tree_insert (node,root->right);
    } 

  return root;
}


/* Parse a .tsv file line by line, create a BusinessNode for each entry, and
 * enter that node into a new BST. Return a pointer to the root of the BST.
 *
 * The explode(...) function from PA03 may be useful for breaking up a lines 
 * into seperate fields. 
 */

char * * explode(const char * str, const char * delims, int * arrLen)
{
  int ind; 
  * arrLen = 1;
  char * temp;
  int index1 = 0; // array index
  for(ind = 0; ind < strlen(str) ; ind++)
    {
      if(strchr(delims,str[ind]) != NULL)
	{
          (*arrLen)++;
	}
    }
  char * * arr1; // 2D array 
  arr1 = malloc(sizeof(char *) * (*arrLen));
  int row; 
  ind = 0; 
  int strlength = 0;
  int startLeft = 0; 
  int startRight = 0;
  for(row = 0; row < (*arrLen); row++) 
    {
      while((strchr(delims,str[ind]) == NULL)&& (str[ind] != '\0'))
	{
          strlength++;
          ind++;
	}
          temp = malloc(sizeof(char) * (strlength+1));
          temp[0] = '\0';
            startLeft = startRight;
           startRight = ind + 1;  
	   strncpy(temp,&(str[startLeft]),strlength);
          temp[strlength] = '\0';
          arr1[index1] = temp; 
          index1++; 
          strlength = 0; 
          ind++;
    }
  return (char * *)(arr1);
}

BusinessNode * load_tree_from_file(char * filename)
{
  int  len = 3; 
  FILE * ptr = fopen(filename, "r"); 
  char * line = malloc(sizeof(char)* 2048);
  char * * vals; 
  // char * v1; 
  // char * v2; 
  // char * v3; 
  BusinessNode * node;
  BusinessNode * root = NULL;
  if(ptr == NULL) 
    { 
      free(line);
      return NULL; 
    } 
  while(fgets(line,2048,ptr) != NULL)
    {
      
      vals = explode(line, "\t\t\0", &len); 
      
      //v1 = strdup(vals[0]);
      //v2 = strdup(vals[1]);
      //v3 = strdup(vals[2]);
      node = create_node(vals[0],vals[1],vals[2]);
      root = tree_insert(node,root);
      free(vals);
    }
  free(line);
  fclose(ptr);
  return root;
}


/* Search a BusinessNode BST for the node with the name 'name'. Returns
 * pointer to the node with a match.
 *
 * If there is no match, return NULL.
 */
BusinessNode * tree_search_name(char * name, BusinessNode * root)
{ 
  if(root == NULL) 
    { 
      return NULL;
    } 
  if(strcmp(name, root->name) == 0)
  {
    return root;
  } 
  if(strcmp(name, root->name) < 0 ) 
    { 
      return tree_search_name(name, root->left);
    } 
  return tree_search_name(name, root->right);
}

/* Print out a single node: name, address, and stars
 * The format can be similar to this:
 *
 * Country Cafe
 * ============
 * Stars:
 *    3.5
 * Address:
 *    1030 Emerald Ter, Sun Prairie, WI 53590
 *
 * This function is not graded, but it could come in very handful while
 * debugging this assignment.
 */
void print_node(BusinessNode * node)
{
}

/* Print the entire tree, starting from the root. Like the print_node(...)
 * function, this is not graded.
 */
void print_tree(BusinessNode * tree)
{
}

/* Deallocate all of the memory used by a BusinessNode BST, without memory
 * leaks.
 */
void destroy_tree(BusinessNode * root)
{
  if(root == NULL) 
    { 
      return; 
    } 
  destroy_tree(root -> left);
  destroy_tree(root ->right); 
  free(root->stars); 
  free(root->name);
  free(root->address); 
  free(root); 
}
